// Restaurant Recommender App
// Mock data for restaurants
const restaurants = [
    {
        id: 1,
        name: "Pasta Paradise",
        cuisine: "italian",
        description: "Authentic Italian pasta and pizza in a cozy atmosphere with traditional recipes passed down through generations.",
        rating: 4.7,
        price: "$$$",
        address: "123 Main St",
        image: "https://images.unsplash.com/photo-1579684947550-22e945225d9a?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=80",
        reactions: {
            "👍": 42,
            "😍": 38,
            "🔥": 27,
            "🤤": 31
        }
    },
    {
        id: 2,
        name: "Sushi Sensation",
        cuisine: "japanese",
        description: "Fresh, high-quality sushi and sashimi prepared by master chefs using traditional Japanese techniques.",
        rating: 4.9,
        price: "$$$$",
        address: "456 Ocean Ave",
        image: "https://images.unsplash.com/photo-1579871494447-9811cf80d66c?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=80",
        reactions: {
            "👍": 56,
            "😍": 67,
            "🔥": 34,
            "🤤": 49
        }
    },
    {
        id: 3,
        name: "Taco Town",
        cuisine: "mexican",
        description: "Vibrant Mexican street food with handmade tortillas, fresh salsas, and margaritas that transport you to Mexico.",
        rating: 4.5,
        price: "$$",
        address: "789 Spice Lane",
        image: "https://images.unsplash.com/photo-1565299585323-38d6b0865b47?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=80",
        reactions: {
            "👍": 38,
            "😍": 29,
            "🔥": 45,
            "🤤": 33
        }
    },
    {
        id: 4,
        name: "Curry House",
        cuisine: "indian",
        description: "Rich, aromatic Indian curries and freshly baked naan in a colorful, welcoming environment.",
        rating: 4.6,
        price: "$$",
        address: "101 Spice Road",
        image: "https://images.unsplash.com/photo-1585937421612-70a008356cf4?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=80",
        reactions: {
            "👍": 41,
            "😍": 36,
            "🔥": 52,
            "🤤": 44
        }
    },
    {
        id: 5,
        name: "Peking Duck Palace",
        cuisine: "chinese",
        description: "Specializing in perfectly roasted Peking duck and authentic Chinese dishes from various regions.",
        rating: 4.8,
        price: "$$$",
        address: "202 Dragon St",
        image: "https://images.unsplash.com/photo-1563245372-f21724e3856d?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=80",
        reactions: {
            "👍": 47,
            "😍": 39,
            "🔥": 28,
            "🤤": 51
        }
    },
    {
        id: 6,
        name: "Thai Delight",
        cuisine: "thai",
        description: "Bold Thai flavors with the perfect balance of sweet, sour, salty and spicy in every authentic dish.",
        rating: 4.4,
        price: "$$",
        address: "303 Basil Blvd",
        image: "https://images.unsplash.com/photo-1559314809-0d155014e29e?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=80",
        reactions: {
            "👍": 35,
            "😍": 28,
            "🔥": 46,
            "🤤": 32
        }
    },
    {
        id: 7,
        name: "Burger Bistro",
        cuisine: "american",
        description: "Gourmet burgers made with locally sourced ingredients and creative toppings that elevate the classic American favorite.",
        rating: 4.3,
        price: "$$",
        address: "404 Patty Place",
        image: "https://images.unsplash.com/photo-1568901346375-23c9450c58cd?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=80",
        reactions: {
            "👍": 58,
            "😍": 32,
            "🔥": 25,
            "🤤": 47
        }
    },
    {
        id: 8,
        name: "Pasta Pronto",
        cuisine: "italian",
        description: "Quick, delicious pasta dishes with homemade sauces and fresh ingredients in a modern, casual setting.",
        rating: 4.2,
        price: "$$",
        address: "505 Noodle Ave",
        image: "https://images.unsplash.com/photo-1473093295043-cdd812d0e601?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=80",
        reactions: {
            "👍": 31,
            "😍": 24,
            "🔥": 19,
            "🤤": 28
        }
    },
    {
        id: 9,
        name: "Sashimi Supreme",
        cuisine: "japanese",
        description: "Premium quality sashimi and Japanese delicacies with an emphasis on seasonal ingredients and artistic presentation.",
        rating: 4.9,
        price: "$$$$",
        address: "606 Fish St",
        image: "https://images.unsplash.com/photo-1534482421-64566f976cfa?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=80",
        reactions: {
            "👍": 62,
            "😍": 71,
            "🔥": 43,
            "🤤": 58
        }
    },
    {
        id: 10,
        name: "Spice Garden",
        cuisine: "indian",
        description: "A culinary journey through India with regional specialties and house-blended spices that create unforgettable flavors.",
        rating: 4.7,
        price: "$$$",
        address: "707 Curry Lane",
        image: "https://images.unsplash.com/photo-1565557623262-b51c2513a641?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=80",
        reactions: {
            "👍": 45,
            "😍": 39,
            "🔥": 56,
            "🤤": 48
        }
    },
    {
        id: 11,
        name: "Dragon Wok",
        cuisine: "chinese",
        description: "Traditional Chinese wok cooking with fresh ingredients and authentic flavors from different provinces of China.",
        rating: 4.5,
        price: "$$",
        address: "808 Bamboo Rd",
        image: "https://images.unsplash.com/photo-1525755662778-989d0524087e?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=80",
        reactions: {
            "👍": 39,
            "😍": 31,
            "🔥": 27,
            "🤤": 42
        }
    },
    {
        id: 12,
        name: "Taqueria Autentica",
        cuisine: "mexican",
        description: "Family-owned taqueria serving authentic Mexican street tacos with homemade salsas and traditional recipes.",
        rating: 4.6,
        price: "$",
        address: "909 Salsa St",
        image: "https://images.unsplash.com/photo-1551504734-5ee1c4a1479b?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=80",
        reactions: {
            "👍": 52,
            "😍": 38,
            "🔥": 49,
            "🤤": 45
        }
    }
];

// DOM Elements
const restaurantListEl = document.getElementById('restaurant-list');
const cuisineTagsEl = document.getElementById('cuisine-tags');
const searchInputEl = document.getElementById('search-input');
const searchButtonEl = document.getElementById('search-button');
const sortSelectEl = document.getElementById('sort-select');
const cardTemplate = document.getElementById('restaurant-card-template');

// App State
let currentCuisine = 'all';
let currentSort = 'rating';
let currentSearch = '';
let userReactions = JSON.parse(localStorage.getItem('userReactions')) || {};

// Initialize the app
function initApp() {
    renderRestaurants();
    setupEventListeners();
    
    // Show welcome toast
    showToast('Welcome to Tasty Picks! Find your next favorite restaurant.');
}

// Set up event listeners
function setupEventListeners() {
    // Cuisine filter buttons
    cuisineTagsEl.addEventListener('click', (e) => {
        if (e.target.classList.contains('cuisine-tag')) {
            const cuisine = e.target.dataset.cuisine;
            setActiveCuisine(cuisine);
            renderRestaurants();
        }
    });
    
    // Search functionality
    searchButtonEl.addEventListener('click', handleSearch);
    searchInputEl.addEventListener('keyup', (e) => {
        if (e.key === 'Enter') {
            handleSearch();
        }
    });
    
    // Sort functionality
    sortSelectEl.addEventListener('change', () => {
        currentSort = sortSelectEl.value;
        renderRestaurants();
    });
    
    // Restaurant list event delegation for reactions
    restaurantListEl.addEventListener('click', (e) => {
        if (e.target.closest('.reaction-btn')) {
            const button = e.target.closest('.reaction-btn');
            const restaurantId = parseInt(button.closest('.restaurant-card').dataset.id);
            const emoji = button.dataset.emoji;
            
            handleReaction(restaurantId, emoji);
        }
    });
}

// Handle search functionality
function handleSearch() {
    currentSearch = searchInputEl.value.trim().toLowerCase();
    renderRestaurants();
}

// Set active cuisine filter
function setActiveCuisine(cuisine) {
    currentCuisine = cuisine;
    
    // Update UI
    document.querySelectorAll('.cuisine-tag').forEach(tag => {
        tag.classList.remove('active');
        if (tag.dataset.cuisine === cuisine) {
            tag.classList.add('active');
        }
    });
}

// Handle emoji reactions
function handleReaction(restaurantId, emoji) {
    const reactionKey = `${restaurantId}-${emoji}`;
    
    // Check if user has already reacted with this emoji
    if (userReactions[reactionKey]) {
        // Remove reaction
        userReactions[reactionKey] = false;
        
        // Update restaurant data
        const restaurant = restaurants.find(r => r.id === restaurantId);
        if (restaurant) {
            restaurant.reactions[emoji]--;
        }
    } else {
        // Add reaction
        userReactions[reactionKey] = true;
        
        // Update restaurant data
        const restaurant = restaurants.find(r => r.id === restaurantId);
        if (restaurant) {
            restaurant.reactions[emoji]++;
        }
        
        // Show toast
        showToast(`You reacted with ${emoji} to ${restaurant.name}!`);
    }
    
    // Save to localStorage
    localStorage.setItem('userReactions', JSON.stringify(userReactions));
    
    // Update UI
    updateReactionUI(restaurantId);
}

// Update reaction UI for a specific restaurant
function updateReactionUI(restaurantId) {
    const card = document.querySelector(`.restaurant-card[data-id="${restaurantId}"]`);
    if (!card) return;
    
    const restaurant = restaurants.find(r => r.id === restaurantId);
    if (!restaurant) return;
    
    const reactionButtons = card.querySelectorAll('.reaction-btn');
    
    reactionButtons.forEach(button => {
        const emoji = button.dataset.emoji;
        const countEl = button.querySelector('.count');
        const reactionKey = `${restaurantId}-${emoji}`;
        
        // Update count
        countEl.textContent = restaurant.reactions[emoji];
        
        // Update active state
        if (userReactions[reactionKey]) {
            button.classList.add('active');
        } else {
            button.classList.remove('active');
        }
    });
}

// Filter restaurants based on current filters
function filterRestaurants() {
    return restaurants.filter(restaurant => {
        // Filter by cuisine
        const cuisineMatch = currentCuisine === 'all' || restaurant.cuisine === currentCuisine;
        
        // Filter by search
        const searchMatch = currentSearch === '' || 
            restaurant.name.toLowerCase().includes(currentSearch) || 
            restaurant.description.toLowerCase().includes(currentSearch) ||
            restaurant.cuisine.toLowerCase().includes(currentSearch);
        
        return cuisineMatch && searchMatch;
    });
}

// Sort restaurants based on current sort option
function sortRestaurants(filteredRestaurants) {
    return [...filteredRestaurants].sort((a, b) => {
        switch (currentSort) {
            case 'rating':
                return b.rating - a.rating;
            case 'name':
                return a.name.localeCompare(b.name);
            case 'likes':
                return b.reactions['👍'] - a.reactions['👍'];
            default:
                return 0;
        }
    });
}

// Render restaurants to the DOM
function renderRestaurants() {
    // Clear current list
    restaurantListEl.innerHTML = '';
    
    // Show loading spinner
    const loadingEl = document.createElement('div');
    loadingEl.className = 'loading';
    loadingEl.innerHTML = '<div class="loading-spinner"></div>';
    restaurantListEl.appendChild(loadingEl);
    
    // Simulate loading delay for better UX
    setTimeout(() => {
        // Filter and sort restaurants
        const filteredRestaurants = filterRestaurants();
        const sortedRestaurants = sortRestaurants(filteredRestaurants);
        
        // Remove loading spinner
        restaurantListEl.innerHTML = '';
        
        // Check if no results
        if (sortedRestaurants.length === 0) {
            const noResultsEl = document.createElement('div');
            noResultsEl.className = 'no-results';
            noResultsEl.textContent = 'No restaurants found. Try adjusting your filters.';
            restaurantListEl.appendChild(noResultsEl);
            return;
        }
        
        // Render each restaurant
        sortedRestaurants.forEach((restaurant, index) => {
            const card = createRestaurantCard(restaurant);
            
            // Add staggered animation delay
            card.style.animationDelay = `${index * 0.1}s`;
            
            restaurantListEl.appendChild(card);
        });
    }, 500);
}

// Create a restaurant card element
function createRestaurantCard(restaurant) {
    // Clone the template
    const card = cardTemplate.content.cloneNode(true).querySelector('.restaurant-card');
    
    // Set restaurant ID
    card.dataset.id = restaurant.id;
    
    // Set image
    const imgEl = card.querySelector('.restaurant-image img');
    imgEl.src = restaurant.image;
    imgEl.alt = restaurant.name;
    
    // Set cuisine badge
    const cuisineBadgeEl = card.querySelector('.cuisine-badge');
    cuisineBadgeEl.textContent = restaurant.cuisine.charAt(0).toUpperCase() + restaurant.cuisine.slice(1);
    
    // Set name
    card.querySelector('.restaurant-name').textContent = restaurant.name;
    
    // Set rating
    const ratingEl = card.querySelector('.restaurant-rating');
    ratingEl.innerHTML = generateStarRating(restaurant.rating);
    
    // Set description
    card.querySelector('.restaurant-description').textContent = restaurant.description;
    
    // Set price and address
    card.querySelector('.restaurant-price').textContent = restaurant.price;
    card.querySelector('.restaurant-address').textContent = restaurant.address;
    
    // Set reaction counts
    const reactionButtons = card.querySelectorAll('.reaction-btn');
    reactionButtons.forEach(button => {
        const emoji = button.dataset.emoji;
        const countEl = button.querySelector('.count');
        countEl.textContent = restaurant.reactions[emoji];
        
        // Check if user has reacted
        const reactionKey = `${restaurant.id}-${emoji}`;
        if (userReactions[reactionKey]) {
            button.classList.add('active');
        }
    });
    
    return card;
}

// Generate star rating HTML
function generateStarRating(rating) {
    const fullStars = Math.floor(rating);
    const halfStar = rating % 1 >= 0.5;
    const emptyStars = 5 - fullStars - (halfStar ? 1 : 0);
    
    let starsHTML = '';
    
    // Full stars
    for (let i = 0; i < fullStars; i++) {
        starsHTML += '<i class="fas fa-star"></i>';
    }
    
    // Half star
    if (halfStar) {
        starsHTML += '<i class="fas fa-star-half-alt"></i>';
    }
    
    // Empty stars
    for (let i = 0; i < emptyStars; i++) {
        starsHTML += '<i class="far fa-star"></i>';
    }
    
    // Add rating number
    starsHTML += `<span style="margin-left: 5px;">${rating}</span>`;
    
    return starsHTML;
}

// Show toast notification
function showToast(message) {
    // Create toast element if it doesn't exist
    let toastEl = document.querySelector('.toast');
    if (!toastEl) {
        toastEl = document.createElement('div');
        toastEl.className = 'toast';
        document.body.appendChild(toastEl);
    }
    
    // Set message
    toastEl.textContent = message;
    
    // Show toast
    toastEl.classList.add('show');
    
    // Hide toast after 3 seconds
    setTimeout(() => {
        toastEl.classList.remove('show');
    }, 3000);
}

// Initialize the app when DOM is loaded
document.addEventListener('DOMContentLoaded', initApp);
