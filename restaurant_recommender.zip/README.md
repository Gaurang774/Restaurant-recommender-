# Tasty Picks - Restaurant Recommender

A frontend-only web application for restaurant recommendations with cuisine filtering and emoji reactions.

## Features

- **Modern UI/UX Design**: Clean, responsive interface that works on both desktop and mobile devices
- **Cuisine Filtering**: Filter restaurants by cuisine type (Italian, Japanese, Mexican, etc.)
- **Search Functionality**: Search for restaurants by name, description, or cuisine
- **Sorting Options**: Sort restaurants by rating, name, or popularity
- **Emoji Reactions**: React to restaurants with emoji reactions (👍, 😍, 🔥, 🤤)
- **Persistent Reactions**: User reactions are saved to localStorage
- **Responsive Design**: Optimized for all screen sizes
- **Smooth Animations**: Enhances user experience with subtle animations and transitions

## Project Structure

```
restaurant_recommender/
├── css/
│   └── style.css       # Main stylesheet
├── js/
│   └── app.js          # JavaScript functionality
├── img/                # Directory for images (empty)
├── index.html          # Main HTML file
└── README.md           # This documentation
```

## Technical Implementation

- **Frontend Only**: No backend required, all data is stored in the browser
- **Vanilla JavaScript**: No frameworks used, just pure JavaScript
- **Responsive CSS**: Custom CSS with media queries for responsive design
- **Mock Data**: Includes realistic restaurant data for demonstration
- **LocalStorage**: Saves user reactions between sessions

## How to Use

1. Open `index.html` in any modern web browser
2. Browse restaurants sorted by rating (default)
3. Filter by cuisine using the cuisine tag buttons
4. Search for specific restaurants using the search bar
5. Sort restaurants by rating, name, or likes
6. React to restaurants with emoji buttons
7. Your reactions will be saved for future visits

## Browser Compatibility

Tested and working on:
- Chrome (latest)
- Firefox (latest)
- Safari (latest)
- Edge (latest)
- Mobile browsers (iOS Safari, Android Chrome)

## Future Enhancements

Potential features for future versions:
- User accounts and personalized recommendations
- Location-based filtering
- Reviews and comments
- Integration with real restaurant data API
- Dark mode toggle

## Credits

- Font Awesome for icons
- Unsplash for restaurant images
